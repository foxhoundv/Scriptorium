const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const archiver = require('archiver');
const { marked } = require('marked');
const PDFDocument = require('pdfkit');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || '/data';
const PROJECTS_DIR = path.join(DATA_DIR, 'projects');

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Ensure data dir exists
fs.ensureDirSync(PROJECTS_DIR);

// ─── PROJECTS ───────────────────────────────────────────────────────────────

app.get('/api/projects', async (req, res) => {
  try {
    const dirs = await fs.readdir(PROJECTS_DIR);
    const projects = [];
    for (const dir of dirs) {
      const metaPath = path.join(PROJECTS_DIR, dir, 'meta.json');
      if (await fs.pathExists(metaPath)) {
        const meta = await fs.readJson(metaPath);
        projects.push(meta);
      }
    }
    projects.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    res.json(projects);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/projects', async (req, res) => {
  try {
    const { title, description, genre } = req.body;
    const id = uuidv4();
    const now = new Date().toISOString();
    const meta = { id, title: title || 'Untitled Project', description: description || '', genre: genre || '', createdAt: now, updatedAt: now, wordCount: 0 };
    const projectDir = path.join(PROJECTS_DIR, id);
    await fs.ensureDir(projectDir);
    await fs.writeJson(path.join(projectDir, 'meta.json'), meta, { spaces: 2 });

    // Default structure
    const structure = {
      id: 'root',
      type: 'folder',
      title: 'Manuscript',
      children: [
        { id: uuidv4(), type: 'folder', title: 'Chapter 1', children: [
          { id: uuidv4(), type: 'document', title: 'Scene 1', children: [] }
        ]},
      ]
    };
    await fs.writeJson(path.join(projectDir, 'structure.json'), structure, { spaces: 2 });
    await fs.ensureDir(path.join(projectDir, 'documents'));

    // Research & Notes folders
    const notesStructure = {
      id: 'notes-root',
      type: 'folder',
      title: 'Research & Notes',
      children: [
        { id: uuidv4(), type: 'document', title: 'Characters', children: [] },
        { id: uuidv4(), type: 'document', title: 'World Building', children: [] },
        { id: uuidv4(), type: 'document', title: 'Plot Outline', children: [] },
      ]
    };
    await fs.writeJson(path.join(projectDir, 'notes-structure.json'), notesStructure, { spaces: 2 });

    res.json(meta);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/projects/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const projectDir = path.join(PROJECTS_DIR, id);
    const metaPath = path.join(projectDir, 'meta.json');
    const meta = await fs.readJson(metaPath);
    const updated = { ...meta, ...req.body, id, updatedAt: new Date().toISOString() };
    await fs.writeJson(metaPath, updated, { spaces: 2 });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/projects/:id', async (req, res) => {
  try {
    const projectDir = path.join(PROJECTS_DIR, req.params.id);
    await fs.remove(projectDir);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── STRUCTURE ──────────────────────────────────────────────────────────────

app.get('/api/projects/:id/structure', async (req, res) => {
  try {
    const structurePath = path.join(PROJECTS_DIR, req.params.id, 'structure.json');
    const structure = await fs.readJson(structurePath);
    res.json(structure);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/projects/:id/structure', async (req, res) => {
  try {
    const structurePath = path.join(PROJECTS_DIR, req.params.id, 'structure.json');
    await fs.writeJson(structurePath, req.body, { spaces: 2 });
    await updateProjectMeta(req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/projects/:id/notes-structure', async (req, res) => {
  try {
    const p = path.join(PROJECTS_DIR, req.params.id, 'notes-structure.json');
    const structure = await fs.readJson(p);
    res.json(structure);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/projects/:id/notes-structure', async (req, res) => {
  try {
    const p = path.join(PROJECTS_DIR, req.params.id, 'notes-structure.json');
    await fs.writeJson(p, req.body, { spaces: 2 });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── DOCUMENTS ──────────────────────────────────────────────────────────────

app.get('/api/projects/:id/documents/:docId', async (req, res) => {
  try {
    const docPath = path.join(PROJECTS_DIR, req.params.id, 'documents', `${req.params.docId}.json`);
    if (await fs.pathExists(docPath)) {
      res.json(await fs.readJson(docPath));
    } else {
      res.json({ id: req.params.docId, content: '', synopsis: '', status: 'draft', labels: [], wordCount: 0 });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/projects/:id/documents/:docId', async (req, res) => {
  try {
    const docsDir = path.join(PROJECTS_DIR, req.params.id, 'documents');
    await fs.ensureDir(docsDir);
    const docPath = path.join(docsDir, `${req.params.docId}.json`);
    const content = req.body.content || '';
    const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
    const doc = { ...req.body, id: req.params.docId, wordCount, updatedAt: new Date().toISOString() };
    await fs.writeJson(docPath, doc, { spaces: 2 });
    await updateProjectMeta(req.params.id);
    res.json(doc);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── EXPORT ─────────────────────────────────────────────────────────────────

app.get('/api/projects/:id/export/txt', async (req, res) => {
  try {
    const text = await compileManuscript(req.params.id, 'txt');
    const meta = await fs.readJson(path.join(PROJECTS_DIR, req.params.id, 'meta.json'));
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Content-Disposition', `attachment; filename="${sanitize(meta.title)}.txt"`);
    res.send(text);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/projects/:id/export/md', async (req, res) => {
  try {
    const text = await compileManuscript(req.params.id, 'md');
    const meta = await fs.readJson(path.join(PROJECTS_DIR, req.params.id, 'meta.json'));
    res.setHeader('Content-Type', 'text/markdown');
    res.setHeader('Content-Disposition', `attachment; filename="${sanitize(meta.title)}.md"`);
    res.send(text);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/projects/:id/export/html', async (req, res) => {
  try {
    const md = await compileManuscript(req.params.id, 'md');
    const meta = await fs.readJson(path.join(PROJECTS_DIR, req.params.id, 'meta.json'));
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${meta.title}</title>
    <style>body{font-family:Georgia,serif;max-width:800px;margin:2rem auto;line-height:1.8;color:#222;}
    h1{font-size:2.5rem;text-align:center;margin-bottom:0.5rem;}
    h2{font-size:1.8rem;margin-top:3rem;page-break-before:always;}
    h3{font-size:1.3rem;margin-top:2rem;color:#555;}</style></head>
    <body>${marked(md)}</body></html>`;
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Disposition', `attachment; filename="${sanitize(meta.title)}.html"`);
    res.send(html);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/projects/:id/export/pdf', async (req, res) => {
  try {
    const text = await compileManuscript(req.params.id, 'txt');
    const meta = await fs.readJson(path.join(PROJECTS_DIR, req.params.id, 'meta.json'));
    const doc = new PDFDocument({ margin: 80, size: 'A4' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${sanitize(meta.title)}.pdf"`);
    doc.pipe(res);
    doc.fontSize(28).font('Times-BoldItalic').text(meta.title, { align: 'center' });
    if (meta.description) {
      doc.moveDown().fontSize(12).font('Times-Italic').text(meta.description, { align: 'center' });
    }
    doc.moveDown(3);
    doc.fontSize(12).font('Times-Roman');
    const lines = text.split('\n');
    for (const line of lines) {
      if (line.startsWith('# ')) {
        doc.addPage().fontSize(22).font('Times-Bold').text(line.replace(/^# /, ''), { align: 'center' });
        doc.moveDown(2).fontSize(12).font('Times-Roman');
      } else if (line.startsWith('## ')) {
        doc.moveDown().fontSize(16).font('Times-Bold').text(line.replace(/^## /, ''));
        doc.moveDown().fontSize(12).font('Times-Roman');
      } else if (line.trim()) {
        doc.text(line, { align: 'justify', paragraphGap: 6 });
      } else {
        doc.moveDown(0.5);
      }
    }
    doc.end();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/projects/:id/export/zip', async (req, res) => {
  try {
    const projectDir = path.join(PROJECTS_DIR, req.params.id);
    const meta = await fs.readJson(path.join(projectDir, 'meta.json'));
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${sanitize(meta.title)}-backup.zip"`);
    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.pipe(res);
    archive.directory(projectDir, meta.title);
    await archive.finalize();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── HELPERS ────────────────────────────────────────────────────────────────

async function updateProjectMeta(projectId) {
  const projectDir = path.join(PROJECTS_DIR, projectId);
  const metaPath = path.join(projectDir, 'meta.json');
  const meta = await fs.readJson(metaPath);
  const docsDir = path.join(projectDir, 'documents');
  let totalWords = 0;
  if (await fs.pathExists(docsDir)) {
    const files = await fs.readdir(docsDir);
    for (const f of files) {
      const doc = await fs.readJson(path.join(docsDir, f));
      totalWords += doc.wordCount || 0;
    }
  }
  meta.wordCount = totalWords;
  meta.updatedAt = new Date().toISOString();
  await fs.writeJson(metaPath, meta, { spaces: 2 });
}

async function flattenStructure(node, projectId) {
  const results = [];
  if (node.type === 'document') {
    const docPath = path.join(PROJECTS_DIR, projectId, 'documents', `${node.id}.json`);
    let content = '';
    if (await fs.pathExists(docPath)) {
      const doc = await fs.readJson(docPath);
      content = doc.content || '';
    }
    results.push({ title: node.title, content });
  }
  for (const child of (node.children || [])) {
    results.push(...await flattenStructure(child, projectId));
  }
  return results;
}

async function compileManuscript(projectId, format) {
  const projectDir = path.join(PROJECTS_DIR, projectId);
  const meta = await fs.readJson(path.join(projectDir, 'meta.json'));
  const structure = await fs.readJson(path.join(projectDir, 'structure.json'));
  const docs = await flattenStructure(structure, projectId);

  if (format === 'txt') {
    let out = `${meta.title}\n${'='.repeat(meta.title.length)}\n\n`;
    if (meta.description) out += `${meta.description}\n\n`;
    for (const doc of docs) {
      out += `\n\n${doc.title}\n${'-'.repeat(doc.title.length)}\n\n${doc.content}\n`;
    }
    return out;
  } else {
    let out = `# ${meta.title}\n\n`;
    if (meta.description) out += `*${meta.description}*\n\n`;
    out += '---\n\n';
    for (const doc of docs) {
      out += `## ${doc.title}\n\n${doc.content}\n\n`;
    }
    return out;
  }
}

function sanitize(name) {
  return name.replace(/[^a-z0-9_\-\s]/gi, '').replace(/\s+/g, '_');
}

// ─── STATS ──────────────────────────────────────────────────────────────────

app.get('/api/projects/:id/stats', async (req, res) => {
  try {
    const projectDir = path.join(PROJECTS_DIR, req.params.id);
    const meta = await fs.readJson(path.join(projectDir, 'meta.json'));
    const structure = await fs.readJson(path.join(projectDir, 'structure.json'));
    const docs = await flattenStructure(structure, req.params.id);
    let totalChars = 0, totalWords = 0, docCount = 0;
    for (const d of docs) {
      if (d.content) {
        totalChars += d.content.length;
        totalWords += d.content.trim() ? d.content.trim().split(/\s+/).length : 0;
        docCount++;
      }
    }
    res.json({ totalWords, totalChars, docCount, title: meta.title, readingTimeMin: Math.ceil(totalWords / 250) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Catch-all
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Scriptorium running on port ${PORT}`);
  console.log(`Data directory: ${DATA_DIR}`);
});
