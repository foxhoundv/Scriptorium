# 📜 Scriptorium

**A self-hosted writing app inspired by Scrivener — designed for Proxmox LXC and Docker.**

All your writing lives on your own server. No subscriptions, no cloud lock-in.

---

## Features

- **Manuscript tree** — Organize your writing into chapters and scenes with drag-and-drop
- **Research & Notes** — Separate section for characters, world-building, outlines
- **Rich text editor** — Bold, italic, headings, blockquotes, lists, with a beautiful paper-like interface
- **Document inspector** — Synopsis, status (Draft/In Progress/Done/Revised), labels, private notes per scene
- **Project word-count goals** — Visual progress bar toward your target
- **Focus mode** — Distraction-free writing (press F11 or click Focus)
- **Dark paper mode** — Toggle between light and dark editor backgrounds
- **Auto-save** — Saves every 1.5 seconds as you type
- **Export formats:**
  - Plain Text (`.txt`)
  - Markdown (`.md`)
  - HTML (`.html`)
  - PDF (`.pdf`) — formatted manuscript
  - ZIP backup (full project backup)
- **Multiple projects** — Dashboard to manage all your books/scripts/projects

---

## Quick Start — Docker

### Option 1: Docker Compose (recommended)

```bash
git clone <your-repo> scriptorium
cd scriptorium
docker compose up -d
```

Open: **http://localhost:3000**

Data is persisted in a Docker volume (`scriptorium_data`).

### Option 2: Docker run

```bash
docker build -t scriptorium .

docker run -d \
  --name scriptorium \
  --restart unless-stopped \
  -p 3000:3000 \
  -v scriptorium_data:/data \
  scriptorium
```

### Backup Docker data

```bash
docker run --rm -v scriptorium_data:/data -v $(pwd):/backup alpine \
  tar czf /backup/scriptorium-backup.tar.gz /data
```

---

## Quick Start — Proxmox LXC

### 1. Create the LXC

In Proxmox, create a new LXC container:
- **Template**: Debian 12 (Bookworm) or Ubuntu 22.04
- **Disk**: 4GB minimum (more for large projects)
- **RAM**: 256MB minimum, 512MB recommended
- **CPU**: 1 core is enough
- **Network**: DHCP or static IP

### 2. Copy the app into the container

From your Proxmox host:
```bash
# Copy source files into the container (replace 101 with your CT ID)
pct push 101 /path/to/scriptorium.tar.gz /tmp/scriptorium.tar.gz
pct exec 101 -- bash -c "mkdir -p /tmp/scriptorium-src && tar xzf /tmp/scriptorium.tar.gz -C /tmp/scriptorium-src --strip-components=1"
```

### 3. Run the installer

```bash
pct exec 101 -- bash /tmp/scriptorium-src/install-lxc.sh
```

The installer will:
- Install Node.js 20
- Create a `scriptorium` system user
- Install the app to `/opt/scriptorium`
- Create data directory at `/var/lib/scriptorium`
- Register and start a **systemd service**

### 4. Access

Open your browser to `http://<LXC-IP>:3000`

### LXC Service Management

```bash
# Status
pct exec 101 -- systemctl status scriptorium

# Restart
pct exec 101 -- systemctl restart scriptorium

# View logs
pct exec 101 -- journalctl -u scriptorium -f
```

### LXC Backup

```bash
# On the LXC, use the built-in ZIP export in the UI, or:
pct exec 101 -- tar czf /tmp/scriptorium-backup.tar.gz /var/lib/scriptorium

# Pull backup to host
pct pull 101 /tmp/scriptorium-backup.tar.gz ./scriptorium-backup.tar.gz
```

---

## Reverse Proxy (Optional)

### Nginx

```nginx
server {
    listen 80;
    server_name scriptorium.yourdomain.local;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## Data Structure

```
/data (or /var/lib/scriptorium)
└── projects/
    └── <project-uuid>/
        ├── meta.json           # Project metadata
        ├── structure.json      # Manuscript tree
        ├── notes-structure.json # Research tree
        └── documents/
            └── <doc-uuid>.json # Each scene/note
```

All data is plain JSON — easy to back up, version-control, or migrate.

---

## Environment Variables

| Variable   | Default           | Description                |
|------------|-------------------|----------------------------|
| `PORT`     | `3000`            | Port to listen on          |
| `DATA_DIR` | `/data`           | Where project data is stored |

---

## Keyboard Shortcuts

| Shortcut     | Action         |
|--------------|----------------|
| `Ctrl+S`     | Save now       |
| `Ctrl+B`     | Bold           |
| `Ctrl+I`     | Italic         |
| `Ctrl+U`     | Underline      |
| `F11`        | Toggle focus mode |

---

## License

MIT — use freely, self-host proudly.
