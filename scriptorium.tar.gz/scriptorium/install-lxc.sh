#!/bin/bash
# ============================================================
#  Scriptorium - LXC Install Script for Proxmox
#  Run this INSIDE a fresh Debian/Ubuntu LXC container
#  as root: bash install-lxc.sh
# ============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo ""
echo -e "${CYAN}╔═══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║        Scriptorium Installer          ║${NC}"
echo -e "${CYAN}║   Self-hosted Writing App for LXC     ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════╝${NC}"
echo ""

# Check root
[[ $EUID -ne 0 ]] && error "Run as root"

# Detect OS
if [ -f /etc/debian_version ]; then
  DISTRO="debian"
elif [ -f /etc/redhat-release ]; then
  DISTRO="rhel"
else
  warn "Unrecognized OS — attempting Debian-style install"
  DISTRO="debian"
fi

info "Updating packages..."
if [ "$DISTRO" = "debian" ]; then
  apt-get update -qq && apt-get install -y -qq curl git
else
  yum install -y curl git
fi

# Install Node.js 20
info "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
if [ "$DISTRO" = "debian" ]; then
  apt-get install -y -qq nodejs
else
  yum install -y nodejs
fi
ok "Node $(node -v) installed"

# Create app user
info "Creating scriptorium user..."
id -u scriptorium &>/dev/null || useradd -r -m -s /bin/bash scriptorium

# Install app
APP_DIR=/opt/scriptorium
DATA_DIR=/var/lib/scriptorium

info "Installing Scriptorium to ${APP_DIR}..."
mkdir -p "$APP_DIR" "$DATA_DIR/projects"
chown -R scriptorium:scriptorium "$DATA_DIR"

# Clone or copy
if [ -d "/tmp/scriptorium-src" ]; then
  cp -r /tmp/scriptorium-src/* "$APP_DIR/"
else
  # Download from local build — adjust URL if hosting elsewhere
  error "Place your scriptorium source in /tmp/scriptorium-src and re-run"
fi

cd "$APP_DIR"
chown -R scriptorium:scriptorium "$APP_DIR"
su -s /bin/bash scriptorium -c "cd $APP_DIR/backend && npm install --production"

ok "Dependencies installed"

# Systemd service
info "Creating systemd service..."
cat > /etc/systemd/system/scriptorium.service << EOF
[Unit]
Description=Scriptorium Writing App
After=network.target

[Service]
Type=simple
User=scriptorium
WorkingDirectory=${APP_DIR}
ExecStart=/usr/bin/node ${APP_DIR}/backend/server.js
Restart=on-failure
RestartSec=5
Environment=PORT=3000
Environment=DATA_DIR=${DATA_DIR}
Environment=NODE_ENV=production

# Hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=${DATA_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable scriptorium
systemctl start scriptorium

sleep 2
if systemctl is-active --quiet scriptorium; then
  ok "Scriptorium service is running"
else
  error "Service failed to start. Check: journalctl -u scriptorium -n 50"
fi

# Get IP
IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║      Scriptorium is running! 🎉       ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}Web UI:${NC}       http://${IP}:3000"
echo -e "  ${CYAN}Data dir:${NC}     ${DATA_DIR}"
echo -e "  ${CYAN}App dir:${NC}      ${APP_DIR}"
echo -e "  ${CYAN}Service:${NC}      systemctl {start|stop|restart|status} scriptorium"
echo -e "  ${CYAN}Logs:${NC}         journalctl -u scriptorium -f"
echo ""
echo -e "  ${YELLOW}Tip:${NC} Back up ${DATA_DIR} regularly to preserve your writing."
echo ""
